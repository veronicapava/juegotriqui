
## Juego Triqui

Este proyecto de prueba está implementado en el famoso Juego Triqui, fue desarrollado con VainillaJS, HTML y CSS.

## Instalación 🔧

Puedes correrlo online desde este link: 


O descargar los 3 archivos y abrir el archivo HTML en el navegador. 

## Autor ✒️

* **Veronica Pava**